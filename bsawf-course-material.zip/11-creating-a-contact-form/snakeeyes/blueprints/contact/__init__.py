from snakeeyes.blueprints.contact.views import contact
